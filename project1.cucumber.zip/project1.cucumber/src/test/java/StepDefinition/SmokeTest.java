/**
 * 
 */
package StepDefinition;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * @author dipika.das
 *
 */
public class SmokeTest {
	
	WebDriver driver;
	
	@Given("^Open Firefox Browser and start application$")
	public void open_Firefox_Browser_and_start_application() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver=new FirefoxDriver();
		System.setProperty("webdriver.gecko.driver","/Users/dipika.das/Documents/workspace2/project1.cucumber/gecodriver");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		 Thread.sleep(3000);
		driver.get("http://10.90.101.183:8080/login.htm");
	}

	@When("^I enter valid \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_enter_valid_and(String uname3, String pass3) throws Throwable {
		WebDriverWait wait = new WebDriverWait(driver, 90);// 1 minute 
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("username")));
		 // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.name("username")).sendKeys(uname3);	
		 Thread.sleep(3000);
		driver.findElement(By.name("password")).sendKeys(pass3);		   
	}

	@Then("^user can able to login successfully$")
	public void user_can_able_to_login_successfully() throws Throwable {
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		 Thread.sleep(9000);
		driver.findElement(By.id("submit")).click();	
	}
	
	@Then("^user can able to navigate various pages$")
	public void user_can_able_to_navigate_various_pages() throws Throwable {
		 Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[1]/div[2]/div/div/div[1]")).click();
		Thread.sleep(9000);
		driver.findElement(By.id("menuCustomSegment")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[1]/div[2]/div/div/div[1]")).click();
		Thread.sleep(9000);
		driver.findElement(By.id("menuDataPartnerModel")).click();
		Thread.sleep(4000);
		driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[1]/div[2]/div/div/div[1]")).click();
		Thread.sleep(9000);
		driver.findElement(By.id("menuLookalikeModel")).click();
		driver.close();

	}
	


	@Then("^Application should be closed$")
	public void application_should_be_closed() throws Throwable {
	driver.close();

	}

}
